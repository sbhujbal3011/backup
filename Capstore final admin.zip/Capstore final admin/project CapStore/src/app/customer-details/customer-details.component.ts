import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/customer';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  customerArr: CustomerModel[];

  constructor() {
    this.customerArr = [];
   }

  ngOnInit() {
  }

}
