import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerDetailsService {
  customerArr: CustomerModel[];
  cutomerObj: CustomerModel;
  constructor(private routes: Router) {
    this.customerArr = [];
  }



}
