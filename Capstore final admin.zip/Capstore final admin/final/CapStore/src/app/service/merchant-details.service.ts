import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { MerchantModel } from '../model/merchant';

@Injectable({
  providedIn: 'root'
})
export class MerchantDetailsService {
   merchantArr: MerchantModel[]
 


constructor() {
      
   

}

}

  