import { TestBed } from '@angular/core/testing';

import { MerchantDetailsService } from './merchant-details.service';

describe('MerchantDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MerchantDetailsService = TestBed.get(MerchantDetailsService);
    expect(service).toBeTruthy();
  });
});
