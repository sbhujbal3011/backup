import { NgModule } from '@angular/core';
import {  MatButtonModule } from '@angular/material';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule} from '@angular/material/icon';

@NgModule({
  imports: [
    MatButtonModule,
    MatMenuModule,MatIconModule
  ],
  exports:[
    MatButtonModule,MatMenuModule,MatIconModule
  ]
})
export class MaterialModule { }
