import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { MerchantModel } from '../model/merchant';
import { CustomerDetailsService } from '../service/customer-details.service';

@Component({
  selector: 'app-merchant-details',
  templateUrl: './merchant-details.component.html',
  styleUrls: ['./merchant-details.component.css']
})
export class MerchantDetailsComponent implements OnInit {
  merchantArr: MerchantModel[];

  

  constructor(private service: CustomerDetailsService) {
    this.merchantArr = [];
  
  }

  ngOnInit() {
    
    this.service.getMerchantDetails().subscribe(data => {
      this.merchantArr = data;
    });
   
  }

}
